#!/usr/bin/python
# -*- coding: utf-8 -*-
import os
import glob
import time
from datetime import datetime
import mysql.connector as mariadb # Permite la conexión entre Python y la base de datos
db = mariadb.connect(host = "localhost", user = "daniel", passwd = "locutus", db = "DS18B20")
cur = db.cursor()
os.system('modprobe w1-gpio')
os.system('modprobe w1-therm')
temp_sensor = '/sys/bus/w1/devices/28-000003bbd16c/w1_slave' # ID del sensor DS18B20
minutos_viejos = 0
contador = 0
temp_1 = 0

def temp_raw():
    f = open(temp_sensor,'r')
    lines = f.readlines()
    f.close
    return lines

def read_temp():
    lines = temp_raw()
    while lines[0].strip()[-3:] != 'YES':
        time.sleep(0.2)
        lines = temp_raw()
    temp_output = lines[1].find('t=')
    if temp_output != -1:
        temp_string = lines[1].strip()[temp_output+2:]
        temp_c = float(temp_string) / 1000.0
        return temp_c

now = datetime.now()
minutos_viejos = now.strftime("%M")
while True:
    now = datetime.now()
    minutos = now.strftime("%M")
    if (minutos_viejos != minutos):
        minutos_viejos = minutos
        contador = contador + 1
        
        if(contador == 30):
            temperatura = str(read_temp())
            if (temp_1 != temperatura):
                temp_1 = temperatura                
                print (temperatura)
    
                try:
                    cur.execute("""INSERT INTO sensor(Temperatura) VALUES('%s')""" % (temperatura))
                    db.commit()
                except:
                    db.rollback()
            contador = 0
cur.close()
db.close()
