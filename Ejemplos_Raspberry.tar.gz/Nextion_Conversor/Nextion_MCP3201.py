import binascii
import time
import spidev
from serial import Serial
import RPi.GPIO as GPIO # Modulo para gestionar los pines GPIO
GPIO.setwarnings(False) # Ignora las advertencias
GPIO.setmode(GPIO.BCM) 	# Los pines serán referidos como Broadcom
spi = spidev.SpiDev()
spi.open(0, 0)
spi.max_speed_hz = 7629
time.sleep(1)
GPIO.setup(16, GPIO.OUT)# Pin 16 será salida
GPIO.output(16, 1)

puerto = Serial("/dev/ttyS0", baudrate=9600, timeout=0.2)
if puerto.isOpen() == False:
    puerto.open()


puerto.flushInput()
puerto.flushOutput()
bandera = 0


def Conversor():
    
    adc = spi.xfer2([0, 0])
    hi = (adc[0] & 0x1F);
    low = (adc[1] & 0xFe);
    dato = (hi << 8) | low;
    puerto.write(b"n0.val=" + str(dato).encode() + b"\xFF\xFF\xFF")
    
while 1:
    Conversor()
    try:   # Recibe los datos desde la pantalla Nextion     
        datos_nextion = binascii.hexlify(puerto.readline()) 
        mensaje = str(datos_nextion)        # Procesa los datos recibidos
        for indice in range(len(mensaje)):  # Recorre los bytes del mensaje
            if indice > 3:                  # Pantalla envió un mensaje?
                if mensaje[7] == "3" and bandera == 0:  # Mensaje del objeto?
                    bandera = 1             # Avisa que el LED está apagado
                    GPIO.output(16, 0)      # Pin 16 pasa a nivel bajo
                else:
                        GPIO.output(16, 1)  # Pin 16 pasa a nivel alto
                        bandera = 0         # Avisa que el LED está encendido
        #print (mensaje)
       
                    
        puerto.flushInput()
        puerto.flushOutput()
        
    except (KeyboardInterrupt, SystemExit):
        puerto.close()
        spi.close()
        GPIO.cleanup()
        raise
