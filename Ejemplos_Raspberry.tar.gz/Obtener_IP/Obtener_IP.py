# =========================================================================
# - Este ejemplo crea un socket e intenta conectar con una IP, no interesa.
# - si esta IP es real lo que interesa es que el el servidor DHCP del router
# - asigne una IP al socket servidor.  
# - Firtec Argentina
# - www.firtec.com.ar
# ==========================================================================
#!/usr/bin/python3
# -*- coding: utf-8 -*-
#!/usr/bin/env python

import socket
from tkinter import Frame
import time


from tkinter import *
from tkinter import ttk

def conseguir_ip():
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
        # doesn't even have to be reachable
            s.connect(('10.255.255.255', 0))
            IP = s.getsockname()[0]
        except:
            IP = '127.0.0.1'
        finally:
            s.close()
        return IP

class Aplicacion():
    def __init__(self):
        global sock
        global ventana
        ventana = Tk()
        ventana.title(' Prueba')
        img = Image("photo", file="11.png")
        ventana.tk.call('wm','iconphoto',ventana._w, img)
        
        #p1 = PhotoImage(file = '11.png') 
        #ventana.iconphoto(False, p1) 
       
        #ventana.geometry("400x250") 
        ventana.resizable(0,0)
        UDP_PORT = 30000  
        Dir_IP = conseguir_ip()
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM) # UDP
        sock.bind((Dir_IP, UDP_PORT))
        sock.setblocking(0)
        ventana.title(Dir_IP) #<<<<<<<<<<<< OJO
          
        #----- Dibujar un rectangulo  -----------------------------
        canvas = Canvas(width=400, height=250, bg='Steel Blue')
        canvas.pack(expand=YES, fill=BOTH)
        canvas.create_rectangle(70, 70, 340, 135, width=5, fill='Steel Blue')
        #-----------------------------------------------------------
        self.label_prueba = Label(ventana, text="0", bg="Steel Blue", fg="black", font=("Helvetica", 28))
        self.label_prueba.place(x=83, y=80)
        self.label_prueba.config(text=Dir_IP)

        ventana.mainloop()

def main():
    mi_app = Aplicacion()
    return 0

if __name__ == '__main__':
    main()
