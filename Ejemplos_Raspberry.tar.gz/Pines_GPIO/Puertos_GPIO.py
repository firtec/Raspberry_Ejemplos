#================================================================
# - Programa ejemplo para el control de ocho pines GPIO.
# - Se controla el estado de los GPIO_19 a GPIO_26.
# - Firtec Argentina
#================================================================
# -*- coding: utf-8 -*-
from tkinter import *
import tkinter.messagebox
import RPi.GPIO as GPIO
GPIO.setmode(GPIO.BCM)
GPIO.setup(19, GPIO.OUT)
GPIO.setup(20, GPIO.OUT)
GPIO.setup(21, GPIO.OUT)
GPIO.setup(22, GPIO.OUT)
GPIO.setup(23, GPIO.OUT)
GPIO.setup(24, GPIO.OUT)
GPIO.setup(25, GPIO.OUT)
GPIO.setup(26, GPIO.OUT)


class MyGui(Frame):
    def __init__(self, parent=None):
        Frame.__init__(self, parent)

def GPIO19_SI():
    GPIO.output(19, GPIO.HIGH)
def GPIO19_NO():
    GPIO.output(19, GPIO.LOW)
def GPIO20_SI():
    GPIO.output(20, GPIO.HIGH)
def GPIO20_NO():
    GPIO.output(20, GPIO.LOW)
def GPIO21_SI():
    GPIO.output(21, GPIO.HIGH)
def GPIO21_NO():
    GPIO.output(21, GPIO.LOW)
def GPIO22_SI():
    GPIO.output(22, GPIO.HIGH)
def GPIO22_NO():
    GPIO.output(22, GPIO.LOW)
def GPIO23_SI():
    GPIO.output(23, GPIO.HIGH)
def GPIO23_NO():
    GPIO.output(23, GPIO.LOW)
def GPIO24_SI():
    GPIO.output(24, GPIO.HIGH)
def GPIO24_NO():
    GPIO.output(24, GPIO.LOW)
def GPIO25_SI():
    GPIO.output(25, GPIO.HIGH)
def GPIO25_NO():
    GPIO.output(25, GPIO.LOW)
def GPIO26_SI():
    GPIO.output(26, GPIO.HIGH)
def GPIO26_NO():
    GPIO.output(26, GPIO.LOW)      

ventana = Tk()

ventana.title('Control de Pines')
ventana.config(bg="beige") # Le da color al fondo
ventana.geometry("300x350") # Cambia el tamaño de la ventana

ventana.resizable(0,0) # Evita que se le pueda cambiar de tamaño a la ventana
boton_0 = Button(ventana, text = 'Led SI (GPIO19)', command = GPIO19_SI)
boton_0.pack()
boton_0.place(x=15, y=7)

boton_1 = Button(ventana, text = 'Led NO (GPIO19)', command = GPIO19_NO)
boton_1.pack()
boton_1.place(x= 160, y=7)

boton_2 = Button(ventana, text = 'Led SI (GPIO20)', command = GPIO20_SI)
boton_2.pack()
boton_2.place(x=15, y=40)

boton_2b = Button(ventana, text = 'Led NO (GPIO20)', command = GPIO20_NO)
boton_2b.pack()
boton_2b.place(x= 160, y=40)


boton_3 = Button(ventana, text = 'Led SI (GPIO21)', command = GPIO21_SI)
boton_3.pack()
boton_3.place(x=15, y=77)

boton_3b = Button(ventana, text = 'Led NO (GPIO21)', command = GPIO21_NO)
boton_3b.pack()
boton_3b.place(x= 160, y=77)


boton_4 = Button(ventana, text = 'Led SI (GPIO22)', command = GPIO22_SI)
boton_4.pack()
boton_4.place(x=15, y=114)

boton_4b = Button(ventana, text = 'Led NO (GPIO22)', command = GPIO22_NO)
boton_4b.pack()
boton_4b.place(x= 160, y=114)

boton_5 = Button(ventana, text = 'Led SI (GPIO23)', command = GPIO23_SI)
boton_5.pack()
boton_5.place(x=15, y=151)

boton_5b = Button(ventana, text = 'Led NO (GPIO23)', command = GPIO23_NO)
boton_5b.pack()
boton_5b.place(x= 160, y=151)

boton_6 = Button(ventana, text = 'Led SI (GPIO24)', command = GPIO24_SI)
boton_6.pack()
boton_6.place(x=15, y=188)

boton_6b = Button(ventana, text = 'Led NO (GPIO24)', command = GPIO24_NO)
boton_6b.pack()
boton_6b.place(x= 160, y=188)

boton_7 = Button(ventana, text = 'Led SI (GPIO25)', command = GPIO25_SI)
boton_7.pack()
boton_7.place(x=15, y=225)

boton_7b = Button(ventana, text = 'Led NO (GPIO25)', command = GPIO25_NO)
boton_7b.pack()
boton_7b.place(x= 160, y=225)

boton_8 = Button(ventana, text = 'Led SI (GPIO26)', command = GPIO26_SI)
boton_8.pack()
boton_8.place(x=15, y=262)

boton_8b = Button(ventana, text = 'Led NO (GPIO26)', command = GPIO26_NO)
boton_8b.pack()
boton_8b.place(x= 160, y=262)

label_firtec = Label(ventana, text = "  www.firtec.com.ar  ", bg = "Steel Blue", fg ="white", font = ("Helvetica", 12))
label_firtec.place (x= 75, y= 310)


ventana.mainloop( )
GPIO.cleanup()
print ("Terminado")