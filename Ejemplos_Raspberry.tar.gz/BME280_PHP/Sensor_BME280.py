#!/usr/bin/env python
# -*- coding: utf-8 -*-
import bme280  #--- Biblioteca del sensor ---
import random
from time import sleep
#import os
#import glob
import time
from datetime import datetime
import mysql.connector as mariadb # Permite la conexión entre Python y la base de datos
db = mariadb.connect(host = "localhost", user = "firtec", passwd = "1234", db = "BME280")
cur = db.cursor()

minutos_viejos = 0
contador = 0
temp_1 = 0

now = datetime.now()
minutos_viejos = now.strftime("%M")
tiempo = 1 #numero = random.randint(15, 60) # Aleatorio entre 15 y 60
while True:
    now = datetime.now()            # Leer el calendario/reloj para este momento
    minutos = now.strftime("%M")    # Obtener el valor de minutos
    if (minutos_viejos != minutos): # Minutos cambió?
        minutos_viejos = minutos    # Ok, entonces actualizar minutos
        contador = contador + 1     # Incrementar el contador de minutos
        
        if(contador == tiempo): # Los minutos son igual a número aleatorio?
            tiempo = random.randint(15, 60) # Nuevo aleatorio entre 15 y 60
            temperatura,presion,humedad = bme280.readBME280All() # Leer el sensor
            # ----- Escalar los datos -----------
            temperatura = ("%.01f") % temperatura
            presion = ("%.01f") % presion
            humedad = ("%.01f") % humedad            
            # ----- Mostrar los datos del sensor -----
            print (temperatura)
            print (presion)
            print (humedad)
            # ----- Insertar los datos del sensor en la base de datos -----
            try:
                cur.execute("""INSERT INTO datos(Temperatura, Humedad, Presion) VALUES(%s, %s, %s)""" %
                            (temperatura, humedad, presion))
                db.commit()
            except:
                db.rollback()
            contador = 0
cur.close()
db.close()


