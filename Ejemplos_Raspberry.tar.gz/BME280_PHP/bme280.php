<html>
 <head>
 <title>BME280</title>
 </head>
 <body>
 <FONT COLOR = "teal">
 <H1 align="center">Sensor BME280 con PHP</h1>
</FONT>
 <H5 align="right">by. Firtec Argentina</h5>
<hr size="2"align="center"noshade="">
<!----------------Inicia código PHP -------------------->
<?php
// Permisos para acceder a la base de datos (dir, usuario,pass, bd)
$conn = mysqli_connect('localhost', 'daniel', 'locutus', 'BME280');
if (!$conn) {
 echo "Error: No se pudo conectar a MySQL." . PHP_EOL;
 echo "errno de depuración: " . mysqli_connect_errno() . PHP_EOL;
 echo "error de depuración: " . mysqli_connect_error() . PHP_EOL;
 exit;
}
?>
<!-- --------------------Termina código PHP ------------------------>
<table border="5"align="center"> <!-- Crea tabla HTML -->
<tr align="center" bottom="middle"> <!-- fila alineado al centro -->
 <td>Temperatura</td> <!-- td crea columna llamada Temperatura -->
 <td>Humedad</td>
 <td>Presión</td>
 <td>Fecha_Hora</td>
 </tr> <!-- Fin de la fila con cuatro columnas -->
<!-- ------------------Inicia nuevo código PHP ------------------- -->
<?php
// Consulta la tabla sensor y guarda en $datos la info leída.
$datos_sensor = mysqli_query($conn,"SELECT * FROM datos");
// Los valores contenidos en $datos_sensor son vectorizados en un $dato_array
while($dato_array = mysqli_fetch_array($datos_sensor)){ ?> <!-- Fin PHP -->

<tr>
 <td align="center"><?php echo $dato_array["Temperatura"]; ?></td>
 <td align="center"><?php echo $dato_array["Humedad"]; ?></td>
 <td align="center"><?php echo $dato_array["Presion"]; ?></td>
 <td><?php echo $dato_array["Fecha"]; ?></td>
 </tr>
 <?php
 }
 ?>
</table>
<hr size="2"align="center"noshade="">
</body>
<!-- ------------------Inicia nuevo código PHP ------------------- -->
<?php
$version = apache_get_version(); // Obtiene la versión de Apache
echo "$version\n"; // Muestra la versión de Apache
echo PHP_OS; // Muestra el sistema operativo
?> <!-- Fin código PHP -->
</html>
