import RPi.GPIO as GPIO
import time

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
boton =  17   # Botón para Interrupt Service Routine (ISR) del contador 
# Pines GPIO para los pines del display de 7 segmentos 
segment8 =  (26,19,13,6,5,11,9,10)
contador = 0
m1 =0
m2 =0
centena =0

GPIO.setup(boton, GPIO.IN, pull_up_down=GPIO.PUD_UP)
 
for segmentos in segment8:
    GPIO.setup(segmentos, GPIO.OUT)
    GPIO.output(segmentos, 0)
    # Digito unidad
    GPIO.setup(7, GPIO.OUT)
    GPIO.output(7, 0) 
    # Digito decena
    GPIO.setup(8, GPIO.OUT)
    GPIO.output(8, 0) 
    
null = [0,0,0,0,0,0,0]
cero = [1,1,1,1,1,1,0]
uno = [0,1,1,0,0,0,0]
dos = [1,1,0,1,1,0,1]
tres = [1,1,1,1,0,0,1]
cuatro = [0,1,1,0,0,1,1]
cinco = [1,0,1,1,0,1,1]
seis = [1,0,1,1,1,1,1]
siete = [1,1,1,0,0,0,0]
ocho = [1,1,1,1,1,1,1]
nueve = [1,1,1,1,0,1,1]

def incrementar(boton):
   global contador
   global m1
   global m2
   contador = contador +1
   if contador > 99: contador = 0
   m2 = contador //10
   m1 = contador % 10
   #Dato_Display(contador)   

def mostrar_dato(valor):
    if valor == 1:
        for i in range(7):
            GPIO.output(segment8[i], uno[i])

    if valor == 2:
        for i in range(7):
            GPIO.output(segment8[i], dos[i])

    if valor == 3:
        for i in range(7):
            GPIO.output(segment8[i], tres[i])

    if valor == 4:
        for i in range(7):
            GPIO.output(segment8[i], cuatro[i])

    if valor == 5:
        for i in range(7):
            GPIO.output(segment8[i], cinco[i])

    if valor == 6:
        for i in range(7):
            GPIO.output(segment8[i], seis[i])

    if valor == 7:
        for i in range(7):
            GPIO.output(segment8[i], siete[i])

    if valor == 8:
        for i in range(7):
            GPIO.output(segment8[i], ocho[i])

    if valor == 9:
        for i in range(7):
            GPIO.output(segment8[i], nueve[i])

    if valor == 0:
        for i in range(7):
            GPIO.output(segment8[i], cero[i])        
            
    return;

# ISR para contar, llama a incrementar() cada vez que se detecta
# un flanco de bajada con una temporización de 250 MiliSegundos
GPIO.add_event_detect(boton, GPIO.FALLING, callback=incrementar, bouncetime=250)

print("Oprima CTRL-C para salir.")
try:
   while True:
       tiempo = 0.004
       #print (m2,m1)
       mostrar_dato (m1)    # Envía al display la unidad
       GPIO.output(7, 1)    # Enciende la unidad 
       time.sleep(tiempo)   # Espera
       GPIO.output(7, 0)    # Apaga la unidad

       mostrar_dato (m2)    # Envía al display la decena
       GPIO.output(8, 1)    # Enciende la decena
       time.sleep(tiempo)   # Espera
       GPIO.output(8, 0)    # Apaga la decena
         
finally:           # Sale del programa
   GPIO.cleanup()  # Libera todos los recursos
   print("\nPrograma terminado.")
