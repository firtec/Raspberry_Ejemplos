import RPi.GPIO as GPIO
from time import sleep

boton =  5   # Botón para Interrupt Service Routine (ISR) del contador
bcdA   = 22  # bit 1 para el CD4511 corresponde al pin 7
bcdB   = 23  # bit 2 para el CD4511 corresponde al pin 1
bcdC   = 24  # bit 4 para el CD4511 corresponde al pin 2
bcdD   = 25  # bit 8 para el CD4511 corresponde al pin 6

contador = 0  # Variable contador

def Leer_Bit(dato, bit):
   return dato & (1 << bit)  # Desplaza el bit y aplica máscara 

def incrementar(boton):
   global contador 
   contador = contador +1
   if contador == 10: contador = 0
   Dato_Display(contador)

# Esta función escribe el dato en el display
def Dato_Display(dato):
   GPIO.output(bcdA, Leer_Bit(dato, 0))  # BCD LSB
   GPIO.output(bcdB, Leer_Bit(dato, 1))
   GPIO.output(bcdC, Leer_Bit(dato, 2))
   GPIO.output(bcdD, Leer_Bit(dato, 3))  # BCD MSB

# Configura los pines
GPIO.setmode(GPIO.BCM)                                
GPIO.setup(boton, GPIO.IN, pull_up_down=GPIO.PUD_UP)  
GPIO.setup(bcdA, GPIO.OUT)
GPIO.setup(bcdB, GPIO.OUT)
GPIO.setup(bcdC, GPIO.OUT)
GPIO.setup(bcdD, GPIO.OUT)

# ISR para contar, llama a incrementar() cada vez que se detecta
# un flanco de bajada con una temporización de 250 MiliSegundos
GPIO.add_event_detect(boton, GPIO.FALLING, callback=incrementar, bouncetime=250)

print("Oprima CTRL-C para salir.")
try:
   while True:
      Dato_Display(contador)  # Actualiza el display
      
finally:           # Sale del programa
   GPIO.cleanup()  # Libera todos los recursos
   print("\nPrograma terminado.")
