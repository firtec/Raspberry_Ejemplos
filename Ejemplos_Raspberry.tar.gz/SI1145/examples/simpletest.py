#!/usr/bin/python

import time
import SI1145.SI1145 as SI1145

sensor = SI1145.SI1145()

while True:
        vis = sensor.readVisible()
        IR = sensor.readIR()
        UV = sensor.readUV()
        uvIndex = UV / 100.0
        print ('Luz Visible:                 ' + str(vis))
        print ('Luz Infrarroja:              ' + str(IR))
        print ('Indice Ultravioleta:         ' + str(uvIndex))
        print ('-----------------------------------')

        time.sleep(3)

