from flask import Flask
app = Flask(__name__)
 
@app.route('/')
def firtec():
    return 'Hola Mundo!'
 
if __name__ == '__main__':
    app.run()
    app.run(host="0.0.0.0")
