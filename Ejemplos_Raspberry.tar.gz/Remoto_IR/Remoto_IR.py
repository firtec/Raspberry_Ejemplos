#!/usr/bin/python
# -*- coding:utf-8 -*-
import RPi.GPIO as GPIO
import time
GPIO.setwarnings(False)
ERROR = 0xFE
PIN = 18				# <------- GPIO donde se conecta el receptor IR
GPIO.setmode(GPIO.BCM)
GPIO.setup(PIN, GPIO.IN, GPIO.PUD_UP)

def getKey():
    byte = [0, 0, 0, 0];
    if IRStart() == False:
        time.sleep(0.5);        
        return ERROR;
    else:
        for i in range(0, 4):
                byte[i] = getByte();
        # La señal de inicio es seguida por cuatro bytes
        # byte[0] 1 byte de dirección
        # byte[1] 1 buye inverso del anterior
        # byte[2] 1 byte de comando
        # byte[3] i byte inverso del anterior
        if byte[0] + byte[1] == 0xff and byte[2] + byte[3] == 0xff:
            return byte[2];
        else:
            return ERROR;
def IRStart():
    timeFallingEdge = [0, 0];
    timeRisingEdge = 0;
    timeSpan = [0, 0];
    GPIO.wait_for_edge(PIN, GPIO.FALLING);
    timeFallingEdge[0] = time.time();
    GPIO.wait_for_edge(PIN, GPIO.RISING);
    timeRisingEdge = time.time();
    GPIO.wait_for_edge(PIN, GPIO.FALLING);
    timeFallingEdge[1] = time.time();
    timeSpan[0] = timeRisingEdge - timeFallingEdge[0];
    timeSpan[1] = timeFallingEdge[1] - timeRisingEdge;
    # Arma los tiempos para el inico y el espacio de 4.5 mS
    if timeSpan[0] > 0.0085 and \
       timeSpan[0] < 0.0095 and \
       timeSpan[1] > 0.004 and \
       timeSpan[1] < 0.005:
        return True;
    else:
        return False;
def getByte():
    byte = 0;
    timeRisingEdge = 0;
    timeFallingEdge = 0;
    timeSpan = 0;
    # Logica '0' == 0.56 ms bajo y 0.56 ms alto
    # Logica '1' == 0.56 ms bajo y 0.169 ms alto
    for i in range(0, 8):
        GPIO.wait_for_edge(PIN, GPIO.RISING);
        timeRisingEdge = time.time();
        GPIO.wait_for_edge(PIN, GPIO.FALLING);
        timeFallingEdge = time.time();
        timeSpan = timeFallingEdge - timeRisingEdge;
        if timeSpan > 0.0016 and timeSpan < 0.0018:
            byte |= 1 << i;
    return byte;
print('Esperando comando IR ...')
try:
    while True:
        key = getKey();
        if(key != ERROR):
            print("Tecla detectada: 0x%02x" %key)
except (KeyboardInterrupt, SystemExit):
        GPIO.cleanup()
        raise

