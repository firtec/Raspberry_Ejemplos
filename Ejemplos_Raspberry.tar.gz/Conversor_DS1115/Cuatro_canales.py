# ================================================================
# - Programa para lectura de cuatro canales del conversor ADS1115
# - Cuatro potenciómetros conectados a los pines A0,A1,A2,A3
# - Conversor conectado a los pines I2C SDA(GPIO2) y SCL(GPIO3)
# - Firtec Argentina
# - www.firtec.com.ar
# ================================================================
import time

# Importa la biblioteca ADS1x15.
import Adafruit_ADS1x15

# Crea instancia para el ADS1115.
adc = Adafruit_ADS1x15.ADS1115()
GAIN = 2

print('Lectura del voltaje en los cuatro canales de ADS1115')
print('(Oprima Ctrl-C para salir.)')
# Print nice channel column hea{ders.
print('| {0:>6} | {1:>6} | {2:>6} | {3:>6} |'.format(*range(4)))
print('-' * 37)

while True:
    ad = [0]*4
    Va = [0]*4
    datos = [0]*4
    for i in range(4):
        ad[i] = adc.read_adc(i, gain=GAIN)
        Va[i] = (ad[i] * 3.3) / float(32768)
        datos[i] = "%.03f" % Va[i]
    print('| {0:>6} | {1:>6} | {2:>6} | {3:>6} |'.format(*datos))
    time.sleep(0.5)
