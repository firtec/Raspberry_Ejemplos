# ================================================================
# - Programa para lectura del conversor ADS1115
# - Se lee el voltaje presente en A0
# - Conversor conectado a los pines I2C SDA(GPIO2) y SCL(GPIO3)
# - Firtec Argentina
# - www.firtec.com.ar
# ================================================================
# -*- coding: utf-8 -*-
import time

# Importa el modulo ADS1x15.
import Adafruit_ADS1x15


# Crea instancia para ADC de 16 bits ADS1115.
adc = Adafruit_ADS1x15.ADS1115()

# Instancia para un ADC de 12-bit instance.
#adc = Adafruit_ADS1x15.ADS1015()

# Se puede cambiar la dirección I2C que por defecto es (0x48)
# usando el parámetro adicional:
#adc = Adafruit_ADS1x15.ADS1015(address=0x49, busnum=1)

# Elija una ganancia de 1 para leer voltajes de 0 a 4.09V.
# O una ganancia diferente para cambiar el rango de voltajes que se leen:
#  - 2/3 = +/-6.144V
#  -   1 = +/-4.096V    Usar con 5 Voltios
#  -   2 = +/-2.048V    Usar con 3.3 Voltios
#  -   4 = +/-1.024V
#  -   8 = +/-0.512V
#  -  16 = +/-0.256V
# Mirar la tabla 3 en la hoja de datos ADS1015/ADS1115.
GAIN = 2 

# Iniciar conversiones ADC continuas en el canal 0 usando la ganancia establecida previamente
adc.start_adc(0, gain=GAIN)
# Una vez que se inician las conversiones, puede llamar a get_last_result () para
# recupere el último resultado, o stop_adc () para detener las conversiones.
# Tenga en cuenta que también puede llamar a start_adc_difference () para tomar un diferencial continuo
# de lecturas.

print('Lectura del Canal 0 del ADS1115')

while 1:
    # Read the last ADC conversion value and print it out.
    value = adc.get_last_result()
    Va = (value * 3.3) / float(32768)
    datos = "%.03f" % Va
    # ¡ADVERTENCIA! Si intenta leer cualquier otro canal ADC durante una
    # conversión (por ejemplo llamando a read_adc nuevamente) desactivará la
    # conversión continua!
    
    # Muestra los datos formateados
    print('Voltios {0}'.format(datos))    
    time.sleep(0.5)   # Espacio entre lecturas

# Detiene la conversión continua. 
adc.stop_adc()
