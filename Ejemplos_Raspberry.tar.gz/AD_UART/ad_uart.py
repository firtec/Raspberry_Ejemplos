#! /usr/bin/python
# -*- coding: utf-8 -*-
from serial import Serial
import time
import RPi.GPIO as GPIO
import spidev
#GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
spi = spidev.SpiDev()
spi.open(0, 0)

#puerto = Serial("/dev/ttyAMA0", baudrate=9600, timeout=2)
puerto = Serial("/dev/ttyS0", baudrate=9600, timeout=2)
if puerto.isOpen() == False:
    puerto.open()


puerto.flushInput()
puerto.flushOutput()


#******************** FUNCIÓN QUE LEE EL COVERSOR *************************
def Conversor():

    M0 =0
    muestras =0
    while muestras <= 15:

        adc = spi.xfer2([1,(8+0)<<4,0])
        dato = ((adc [1] & 3) << 8) + adc[2]
        M0 += dato
        muestras += 1

    dato = M0 / 16
    Va = (dato * 3.3) / float(1023)
    puerto.write("\rVoltios: ".encode())
    puerto.write(str(Va).encode())
    puerto.write("\n".encode())
   
#**************************************************************************
puerto.write("UART & Conversor A/D\n".encode())
while 1:
    try:
        Conversor()
        time.sleep(2)

    except (KeyboardInterrupt, SystemExit):
        puerto.close()
        spi.close()
        GPIO.cleanup()
        raise
