#!/usr/bin/env python
# -*- coding: utf-8 -*-
import spidev
import time
import os
import LCDLIB16x2 as LCD

# Configuración del bus SPI
spi = spidev.SpiDev()
spi.open(0, 0)
spi.max_speed_hz = 7629
V1 = 0.00
V2 = 0.00

#-----------------------------------------------
# Función que leer el dato SPI desde el MCP3008
# El canal deber ser un entero entre 0 y 7

def Lee_Canal(channel):
    adc = spi.xfer2([1,(8+channel)<<4,0])
    dato = ((adc [1] & 3) << 8) + adc[2]
    #global volts
    volts = (dato * 3.3) / float(1023)
    return volts
#-----------------------------------------------
# canal puede tomar cualquier valor entre 0 y 7

def Canal_Selec():
    canal = 0
    global V1
    V1 = Lee_Canal(canal)
    canal += 1
    global V2
    V2 = Lee_Canal(canal)
    canal = 0
#-----------------------------------------------

LCD.lcd_init()
time.sleep(1)
LCD.lcd_string("  MCP3008 & PI",LCD.LINE_1)
delay = 0.1 # Retardo entre mediciones

if __name__ == '__main__':
    try:

        while True:
            Canal_Selec()
            LCD.lcd_string("A0:%.2f A1:%.2f" % (V1, V2), LCD.LINE_2)
            #time.sleep(delay)

    except KeyboardInterrupt:
        GPIO.cleanup()
        sys.exit(0)
