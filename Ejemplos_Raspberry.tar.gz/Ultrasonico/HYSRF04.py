#!/usr/bin/python
# -*- coding:utf-8 -*-
import RPi.GPIO as GPIO
import time
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
 
# Pines GPIO conectados al sensor
GPIO_TRIGGER = 18 
GPIO_ECHO = 24
 
# Sentido de transferencia de los pines
GPIO.setup(GPIO_TRIGGER, GPIO.OUT)
GPIO.setup(GPIO_ECHO, GPIO.IN)
 
def medir():
    # Trigger inicia a nivel alto
    GPIO.output(GPIO_TRIGGER, True)
 
    # Trigger baja luego de 0.01ms
    time.sleep(0.00001)
    GPIO.output(GPIO_TRIGGER, False)
 
    Pulso_Inicio = time.time()
    Pulso_ECO = time.time()
 
    # Almacena eltiempo de pulso de inicio
    while GPIO.input(GPIO_ECHO) == 0:
        Pulso_Inicio = time.time()
 
    # Almacena el tiempo del puso de rebote
    while GPIO.input(GPIO_ECHO) == 1:
        Pulso_ECO = time.time()
 
    # Diferencia entre los dos tiempos de pulso
    TimeElapsed = Pulso_ECO - Pulso_Inicio
    # Multiplicar por la velocidad del sonido 34300 cm/s
    # y dividir por 2 (Ida y Vuelta)
    distancia = (TimeElapsed * 34300) / 2
    return distancia
 
if __name__ == '__main__':
    try:
        while True:
            medir_distancia = medir()
            print ("Distancia medida = %.1f cm" % medir_distancia)
            time.sleep(1)
 
        # Salir con CTRL + C
    except KeyboardInterrupt:
        print("chau :)")
        GPIO.cleanup()

"""
try:
    while True:
        key = getKey();
        if(key != ERROR):
            print("Tecla detectada: 0x%02x" %key)
except (KeyboardInterrupt, SystemExit):
        GPIO.cleanup()
        raise

"""
