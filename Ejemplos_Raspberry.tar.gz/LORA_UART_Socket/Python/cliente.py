# -*- coding: utf-8 -*-
#import RPi.GPIO as GPIO
import time
import socket
import sys
from tkinter.messagebox import showinfo
from tkinter import *
import tkinter as tk
from tkinter import ttk, font

bandera = 0
#GPIO.setwarnings(False)
#GPIO.setmode(GPIO.BCM)

UDP_PORT = 8080
#UDP_PORT = 20080
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM) # UDP

def configurar_IP():
    global UDP_IP
    UDP_IP = dato_dir.get()
    boton.focus_set()
    
#-----------------------------------------------
def apagar( ):
    sock.sendto('4'.encode('utf-8'),  (UDP_IP, UDP_PORT))

def encender( ):
    sock.sendto('5'.encode('utf-8'),  (UDP_IP, UDP_PORT))

ventana = Tk()

ventana.title('UDP')
ventana.config(bg="Steel Blue") # Le da color al fondo
ventana.geometry("200x290") # Cambia el tamaño de la ventana

ventana.resizable(0,0)

label_IP = Label(ventana, text = "Ingrese IP del servidor", bg = "Steel Blue", fg ="white", font = ("Helvetica", 12))
label_IP.place (x= 15, y= 10)

label_firtec = Label(ventana, text = "www.firtec.com.ar", bg = "Steel Blue", fg ="white", font = ("Helvetica", 10))
label_firtec.place (x= 43, y= 235)

dato_dir = StringVar()
caja = Entry(ventana, textvariable= dato_dir, width = 15,justify=tk.CENTER)
caja.place (x=33, y= 40)
caja.focus_set()

boton = Button(ventana, text = "Conectar", command = configurar_IP)
boton.place (x=55, y= 70)
fuente = font.Font(weight='bold') 
label_voltios = Label(ventana, text = "Puerto: 8080", bg = "Steel Blue", fg ="white", font = ("Helvetica", 10))
label_voltios.place (x= 58, y= 100)

boton_0 = Button(ventana,font=fuente, text=' Encender LED ', command=encender)  # Boton del LED
boton_0.pack()
boton_0.place(x=20, y=130)    # Coordenada del Boton

boton_1 = Button(ventana,font=fuente, text='   Apagar LED  ', command=apagar)  # Boton del LED
boton_1.pack()
boton_1.place(x=20, y=180)    # Coordenada del Boton

ventana.mainloop( )


