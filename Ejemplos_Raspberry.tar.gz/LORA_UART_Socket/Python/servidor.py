# -*- coding: utf-8 -*-
#!/usr/bin/env python
import socket
from serial import Serial
import sys
import select
import errno
import time
from tkinter import *
from tkinter.messagebox import showinfo

puerto = Serial("/dev/ttyS0", baudrate=9600, timeout=0.2)

if puerto.isOpen() == False:
    puerto.open()

puerto.flushInput()
puerto.flushOutput()


class MyGui(Frame):
    def __init__(self, parent=None):
        Frame.__init__(self, parent)

def get_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(('10.255.255.255', 0))
        IP = s.getsockname()[0]
    except:
        IP = '127.0.0.1'
    finally:
        s.close()
    return IP

"""
def apagar():
        puerto.write(b'4')
        
def encender():
        puerto.write(b'5')
"""

UDP_PORT = 8080  # Puerto del socket
Dir_IP = get_ip()

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM) 
sock.bind((Dir_IP, UDP_PORT))
sock.setblocking(0)

ventana = Tk()

ventana.title('Puente Socket - LORA')
ventana.config(bg="beige") # Le da color al fondo
ventana.geometry("270x150") # Cambia el tamaño de la ventana
ventana.resizable(0,0) # Evita que se le pueda cambiar de tamaño a la ventana

#************** FUNCIÓN RECURSIVA *******************************
def update_label():
    try:
        dato = sock.recv(1024).decode('utf-8')
        #data, addr = s.recvfrom(1024).decode('utf-8')
    except socket.error as e:
        err = e.args[0]
        if err == errno.EAGAIN or err == errno.EWOULDBLOCK:
            time.sleep(0.01)
            #print 'No hay datos!!'
            ventana.after(1, update_label)
    else:
        #print (dato)
        if (dato == '4'):
            puerto.write(b'4')
            #apagar()
        if (dato == '5'):
            puerto.write(b'5')
            #encender()
        #label.config(text = dato)
        ventana.after(1, update_label)

#****************************************************************


#makemenu(ventana)

label_Nombre_IP = Label(ventana, text="Puente Socket - USART", bg="beige", fg="red", font=("Helvetica", 14))
label_Nombre_IP.place(x=40, y=8)

ventana.title(Dir_IP)


label_IP = Label(ventana, text = "Socket IP:", bg = "beige", fg ="blue", font = ("Helvetica", 12))
label_IP.place (x= 8, y= 40)
titulo = Label(ventana, bg="beige", fg="blue", font=("Helvetica", 12))
titulo.config(text = Dir_IP)
titulo.place(x=90, y=40)

label_IP = Label(ventana, text = "LORA Baudios: 9600", bg = "beige", fg ="blue", font = ("Helvetica", 12))
label_IP.place (x= 8, y= 65)

label_firtec = Label(ventana, text = "www.firtec.com.ar", bg = "beige", fg ="blue", font = ("Helvetica", 10))
label_firtec.place (x= 80, y= 100)
"""
rotulos = Label(ventana, bg="beige", fg="black", font=("Helvetica", 12))
rotulos.config(text = "Sensor 1     Sensor 2     Sensor 3    Sensor 4")
rotulos.place(x=36, y=95)


label = Label(ventana, text="  --------------------------", bg="beige",
fg="red", font=("Helvetica", 25))
label.place(x=30, y=120)
"""

ventana.after(1, update_label)
ventana.mainloop( )
