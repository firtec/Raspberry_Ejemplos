# -*- coding: utf-8 -*-
import RPi.GPIO as GPIO
import LCDLIB16x2		# Importa el driver de la pantalla
LCD.lcd_init()			# Configura la pantalla
while True:  			# Bucle infinito
    LCD.lcd_string("  Rasbperry PI ",LCD.LINE_1)
    LCD.lcd_string("Firtec Argentina",LCD.LINE_2)
GPIO.cleanup()			# Libera el bus GPIO