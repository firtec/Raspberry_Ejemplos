# =========================================================
# - Programa ejemplo para una ventana básica con Python
# - Firtec Argentina
# - www.firtec.com.ar
# =========================================================
# -*- coding: utf-8 -*-
#!/usr/bin/python3
from tkinter import *

ventana = Tk( )

ventana.mainloop( )

