# ===============================================================
# - Programa ejemplo para una ventana básica con Python
# - (Este ejemplo utiliza una clase para la ventana principal)
# - Firtec Argentina
# - www.firtec.com.ar
# ===============================================================
#!/usr/bin/python3
# -*- coding: utf-8 -*-

from tkinter import *
#from tkinter import ttk

class Aplicacion():
    def __init__(self):
        ventana = Tk()
        ventana.title(' Prueba')
        ventana.config(bg="coral") 
        ventana.geometry("400x200") 
        ventana.resizable(0,0)
        label_texto = Label(ventana, text="Hola Mundo!!!", bg="beige", fg="blue", font=("Helvetica", 14))
        label_texto.place(x=30, y=30)
        ventana.mainloop()
    
        
def main():
    mi_app = Aplicacion()
    return 0

if __name__ == '__main__':
    main()
