# -*- coding: utf-8 -*-
import RPi.GPIO as GPIO
import time
import spidev
import socket
import sys
from tkinter.messagebox import showinfo
from tkinter import *
import tkinter as tk

bandera = 0
#GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
spi = spidev.SpiDev()
spi.open(0, 0)
spi.max_speed_hz = 7629

V1 = 0.00
V2 = 0.00
V3 = 0.00
V4 = 0.00

UDP_PORT = 8080
#UDP_PORT = 20080
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM) # UDP

def configurar_IP():
    global UDP_IP
    UDP_IP = dato_dir.get()
    boton.focus_set()
    global bandera
    if bandera == 0:
        ventana.after(5, Canal_Selec)
        bandera = 1
#-----------------------------------------------
# Función que leer el dato SPI desde el MCP3008
# El canal deber ser un entero entre 0 y 7

def Lee_Canal(channel):
    adc = spi.xfer2([1,(8+channel)<<4,0])
    dato = ((adc [1] & 3) << 8) + adc[2]
    temp = dato
    #temp = dato - 0.5
    temp = temp / float(10)
    return temp
#-----------------------------------------------
def Canal_Selec():
    canal = 0
    global V1
    V1 = Lee_Canal(canal)
    #V1 = str(V1).encode()
    canal += 1
    global V2
    V2 = Lee_Canal(canal)
    #V2 = str(V2).encode()
    canal += 1
    global V3
    V3 = Lee_Canal(canal)
    canal += 1
    global V4
    V4 = Lee_Canal(canal)
    canal = 0
    datos = " %.01f  %.01f  %.01f  %.01f " % (V1, V2, V3, V4)
    sock.sendto(str(datos).encode(), (UDP_IP, UDP_PORT))
    ventana.after(2, Canal_Selec)
#-----------------------------------------------

ventana = Tk()

ventana.title('AD_T')
ventana.config(bg="Steel Blue") # Le da color al fondo
ventana.geometry("200x200") # Cambia el tamaño de la ventana

ventana.resizable(0,0)

label_IP = Label(ventana, text = "Ingrese IP del servidor", bg = "Steel Blue", fg ="white", font = ("Helvetica", 12))
label_IP.place (x= 15, y= 10)

label_firtec = Label(ventana, text = "www.firtec.com.ar", bg = "Steel Blue", fg ="white", font = ("Helvetica", 10))
label_firtec.place (x= 43, y= 175)

dato_dir = StringVar()
caja = Entry(ventana, textvariable= dato_dir, width = 15)
caja.place (x=33, y= 40)

boton = Button(ventana, text = "Conectar", command = configurar_IP)
boton.place (x=55, y= 70)

label_voltios = Label(ventana, text = "Puerto: 8080", bg = "Steel Blue", fg ="white", font = ("Helvetica", 10))
label_voltios.place (x= 58, y= 100)

if bandera == 1:
   #print (bandera)
    ventana.after(1, Canal_Selec)

ventana.mainloop( )


