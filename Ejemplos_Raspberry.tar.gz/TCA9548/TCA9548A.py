# ================================================================
# - Programa para lectura de dos acelerómetros MPU6050 mediante
# - un multiplexor I2C TCA9548A.
# - El multipexador conectado a los pines I2C SDA(GPIO2) y SCL(GPIO3)
# - Firtec Argentina
# - www.firtec.com.ar
# ================================================================
import time
import board
import busio
import adafruit_mpu6050
import adafruit_tca9548a

# Crea un bus I2C normal
i2c = busio.I2C(board.SCL, board.SDA)

# Crea un objeto TCA9548A montado sobre el bus I2C
tca = adafruit_tca9548a.TCA9548A(i2c)

# En lugar de un objeto por sensor se usa canal del TCA9548 para los datos.
tsl1 = adafruit_mpu6050.MPU6050(tca[0]) # Contenedor para datos del giroscopio 1
tsl2 = adafruit_mpu6050.MPU6050(tca[1]) # Contenedor para datos del giroscopio 2
print(" Lectura de dos gisroscopos mediante un multiplexor de Bus I2C")
print('=' * 62)
while True: # Bucle principal del programa
    print("Giroscopio 1: X:%.2f, Y: %.2f, Z: %.2f grados/s" % (tsl1.gyro))
    print("Giroscopio 2: X:%.2f, Y: %.2f, Z: %.2f grados/s" % (tsl2.gyro))
    print('*' * 52)
    time.sleep(1)
