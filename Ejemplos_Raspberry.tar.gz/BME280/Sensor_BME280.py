#!/usr/bin/env python
# -*- coding: utf-8 -*-
import bme280  #--- Biblioteca del sensor ---
from time import sleep

while True:
    temperatura,presion,humedad = bme280.readBME280All()
    print("\nTemperature: %0.1f C" % temperatura)
    print ("Presión = %0.2f hPa" % presion)
    print ("Humedad = %0.2f %%" % humedad)
    print ("------------------------")
    
    sleep(5)

