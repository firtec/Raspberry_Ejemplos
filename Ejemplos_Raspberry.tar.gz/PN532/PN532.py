"""
** Descripción  : Lee tarjetas RFID mediante el chip PN532                           
**                Pines: GPIO_2 (SDA) y GPIO_3 (SCL)
**                              
**  Target       : Raspberry PI 4
**  ToolChain    : Python 3.9 
**  www.firtec.com.ar 
"""
import board
import busio
from digitalio import DigitalInOut

#
# NOTE: pick the import that matches the interface being used
#
from adafruit_pn532.i2c import PN532_I2C

# from adafruit_pn532.spi import PN532_SPI
# from adafruit_pn532.uart import PN532_UART

# I2C connection:
i2c = busio.I2C(board.SCL, board.SDA)

# Non-hardware
# pn532 = PN532_I2C(i2c, debug=False)

#Con I2C conectar RSTPD_N (reinicio) a un pin digital para reset de hardware
reset_pin = DigitalInOut(board.D6)
# On Raspberry Pi, you must also connect a pin to P32 "H_Request" for hardware

#req_pin = DigitalInOut(board.D12)
#pn532 = PN532_I2C(i2c, debug=False, reset=reset_pin, req=req_pin)
pn532 = PN532_I2C(i2c, debug=False, reset=reset_pin)
uid_viejo = 0

#------------ Para usar con SPI---------------------
# spi = busio.SPI(board.SCK, board.MOSI, board.MISO)
# cs_pin = DigitalInOut(board.D5)
# pn532 = PN532_SPI(spi, cs_pin, debug=False)

#------------ Para usar con UART---------------------
# UART connection
# uart = busio.UART(board.TX, board.RX, baudrate=115200, timeout=100)
# pn532 = PN532_UART(uart, debug=False)

ic, ver, rev, support = pn532.firmware_version
print("Encontrado PN532 con version de firmware: {0}.{1}".format(ver, rev))

# Configurar la placa con el PN532
pn532.SAM_configuration()

print("----- Esperando por una tarjeta RFID/NFC.-----")
while True:
    # Verificar si hay alguna tarjeta en el area de lectura
    uid = pn532.read_passive_target(timeout=0.5)
   
    if uid is None: # Si no hay tarjeta continuar en el bucle
        continue
    if (uid_viejo != uid):  # La tarjeta es distinta a la anterior?
        uid_viejo = uid     # OK entonce actualizar la tarjeta y mostrarla
        print("Detectada tarjeta con UID:", [hex(i) for i in uid])
