import binascii
import time
from serial import Serial
import RPi.GPIO as GPIO # Modulo para gestionar los pines GPIO

GPIO.setwarnings(False) # Ignora las advertencias
GPIO.setmode(GPIO.BCM) 	# Los pines serán referidos como Broadcom
GPIO.setup(16, GPIO.OUT)# Pin 16 será salida
GPIO.output(16, 1)

puerto = Serial("/dev/ttyS0", baudrate=9600, timeout=0.2)
if puerto.isOpen() == False:
    puerto.open()

puerto.flushInput()
puerto.flushOutput()
bandera = 0
    
while 1:   
    try:   # Recibe los datos desde la pantalla Nextion     
        datos_nextion = binascii.hexlify(puerto.readline()) 
        mensaje = str(datos_nextion)        # Procesa los datos recibidos
        for indice in range(len(mensaje)):  # Recorre los bytes del mensaje
            if indice > 3:                  # Pantalla envió un mensaje?
                if mensaje[7] == "2" and bandera == 0:  # Mensaje del objeto?
                    bandera = 1             # Avisa que el LED está apagado
                    GPIO.output(16, 0)      # Pin 16 pasa a nivel bajo
                else:
                        GPIO.output(16, 1)  # Pin 16 pasa a nivel alto
                        bandera = 0         # Avisa que el LED está encendido
        #print (mensaje)

    except (KeyboardInterrupt, SystemExit):
        puerto.close()
        GPIO.cleanup()
        raise
