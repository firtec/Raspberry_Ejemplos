# -*- coding: utf-8 -*-
#!/usr/bin/env python
import socket
import sys
import select
import errno
import time
from tkinter import *
from tkinter.messagebox import showinfo


class MyGui(Frame):
    def __init__(self, parent=None):
        Frame.__init__(self, parent)

def get_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(('10.255.255.255', 0))
        IP = s.getsockname()[0]
    except:
        IP = '127.0.0.1'
    finally:
        s.close()
    return IP


UDP_PORT = 8080  # Puerto del socket
Dir_IP = get_ip()

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM) 
sock.bind((Dir_IP, UDP_PORT))
sock.setblocking(0)

ventana = Tk()

ventana.title('Sensor MCP9700 & Socket UDP')
ventana.config(bg="beige") # Le da color al fondo
ventana.geometry("400x200") # Cambia el tamaño de la ventana
ventana.resizable(0,0) # Evita que se le pueda cambiar de tamaño a la ventana

w = Canvas(ventana, width=370, height= 100)
w.place(x=10, y=83)
w.config(bg="beige")
w.create_rectangle(10, 10, 360, 90)
x = 0
y = 0

#************** FUNCIÓN RECURSIVA *******************************
def update_label():
    try:
        data = sock.recv(1024)
        #data, addr = s.recvfrom(1024).decode('utf-8')
    except socket.error as e:
        err = e.args[0]
        if err == errno.EAGAIN or err == errno.EWOULDBLOCK:
            time.sleep(0.01)
            #print 'No hay datos!!'
            ventana.after(1, update_label)
    else:
        label.config(text = data)
        ventana.after(1, update_label)

#****************************************************************

def info():
        showinfo(title='Acerca de..', message='Script en Python 3.5 \n www.firtec.com.ar')


def makemenu(parent):
    menubar = Frame(parent)
    menubar.pack(side=TOP, fill=X)

    fbutton = Menubutton(menubar, text='Menu', underline=0)
    fbutton.pack(side=LEFT)
    file = Menu(fbutton)
    file.add_command(label='Acerca de...', command=info,     underline=0)
    file.add_command(label='Salir',    command=parent.quit, underline=0)
    fbutton.config(menu=file)

makemenu(ventana)

label_Nombre_IP = Label(ventana, text="IP:", bg="beige", fg="blue", font=("Helvetica", 14))
label_Nombre_IP.place(x=18, y=31)

label_IP = Label(ventana, bg="beige", fg="blue", font=("Helvetica", 14))
label_IP.config(text = Dir_IP)
label_IP.place(x=44, y=31)

titulo = Label(ventana, bg="beige", fg="black", font=("Helvetica", 14))
titulo.config(text = " Temperatura en los cuatro sensores")
titulo.place(x=32, y=65)

rotulos = Label(ventana, bg="beige", fg="black", font=("Helvetica", 12))
rotulos.config(text = "Sensor 1     Sensor 2     Sensor 3    Sensor 4")
rotulos.place(x=36, y=95)


label = Label(ventana, text="  --------------------------", bg="beige",
fg="red", font=("Helvetica", 25))
label.place(x=30, y=120)


ventana.after(1, update_label)
ventana.mainloop( )
