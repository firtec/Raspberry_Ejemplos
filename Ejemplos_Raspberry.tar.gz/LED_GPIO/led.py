# ===========================================================================================
# - Programa ejemplo para el control de un pin con Python
# - (Este ejemplo cambia de estado el pin 17 al ritmo de un segundo)
# - Firtec Argentina
# - www.firtec.com.ar
# ===========================================================================================
#!/usr/bin/env python		# Ubicación del interprete Python
# -*- coding: utf-8 -*-		# Codificación del archivo Python 
import time				# Modulo para gestionar tiempos
import RPi.GPIO as GPIO # Modulo para gestionar los pines GPIO
GPIO.setwarnings(False) # Ignora las advertencias
GPIO.setmode(GPIO.BCM) 	# Los pines serán referidos como Broadcom
GPIO.setup(17, GPIO.OUT)# Pin 17 será salida

while(1):  				# Bucle infinito
    GPIO.output(17, 0)  	# Pin 17 es puesto a nivel bajo (0)
    time.sleep(1)  			# Espera un segundo
    GPIO.output(17, 1)  	# Pin 17 es puesto a nivel alto (1)
    time.sleep(1)  			# Espera un segundo