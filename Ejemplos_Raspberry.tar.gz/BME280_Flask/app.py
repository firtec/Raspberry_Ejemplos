#!/usr/bin/env python
# -*- coding: utf-8 -*-
import bme280  
from time import sleep

from flask import Flask, render_template, request
app = Flask(__name__)
 
@app.route("/")
def main():  
    temperatura,presion,humedad = bme280.readBME280All()
    temp = "%.01f" % (temperatura)
    hum = "%.01f" % (humedad)
    pres = "%.01f" % (presion)
    return render_template('BME280.html', _temperatura=temp, _humedad=hum, _presion=pres)
    
if __name__ == "__main__":
    app.run(host="0.0.0.0")
    
