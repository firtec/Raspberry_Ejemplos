import binascii
import time
from serial import Serial
import RPi.GPIO as GPIO # Modulo para gestionar los pines GPIO

GPIO.setwarnings(False) # Ignora las advertencias
GPIO.setmode(GPIO.BCM) 	# Los pines serán referidos como Broadcom
pin_boton = 17  #Variable que contiene el pin(GPIO.BCM)
GPIO.setup( pin_boton , GPIO.IN , pull_up_down=GPIO.PUD_UP )


puerto = Serial("/dev/ttyS0", baudrate=9600, timeout=0.2)
if puerto.isOpen() == False:
    puerto.open()

puerto.flushInput()
puerto.flushOutput()
bandera = 0
try:
    
    while 1:
        if GPIO.input( pin_boton ) == GPIO.LOW and bandera == 1:
            puerto.write(b'a')
            bandera = 0
            time.sleep(1)
            
        if GPIO.input( pin_boton ) == GPIO.HIGH and bandera == 0:
            puerto.write(b'b')
            bandera = 1
            time.sleep(1)
    
except (KeyboardInterrupt, SystemExit):
        puerto.close()
        GPIO.cleanup()
#continue
