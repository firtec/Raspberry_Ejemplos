#! /usr/bin/python
# -*- coding: utf-8 -*-
import RPi.GPIO as GPIO
import time
import LCD_LIB as LCD
#GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)

LCD.lcd_init()
LCD.lcd_init()
time.sleep(1)
LCD.lcd_string("  DS18B20 & PI",LCD.LINE_1)

import os
import glob
import time

def read_temp_raw():
    f = open("/sys/bus/w1/devices/28-0000021bc9bd/w1_slave", 'r')
    lines = f.readlines()
    f.close()
    return lines

def read_temp():
    lines = read_temp_raw()
    while lines[0].strip()[-3:] != 'YES':
        time.sleep(0.2)
        lines = read_temp_raw()
    equals_pos = lines[1].find('t=')
    if equals_pos != -1:
        temp_string = lines[1][equals_pos+2:]
        temp_c = float(temp_string) / 1000.0
        return temp_c
    
while True:
    LCD.lcd_string("Temp:%.1f" % read_temp(), LCD.LINE_2)
    time.sleep(0.1)
