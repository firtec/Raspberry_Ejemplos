
# -*- coding: utf-8 -*-
#importar módulos
import RPi.GPIO as GPIO
import time

# Ocultar los Warning
GPIO.setwarnings(False)
# Define el mapa de pines mapa BCM
LCD_RS = 20    #14
LCD_E =  21    #15
LCD_D4 = 22    #18
LCD_D5 = 23
LCD_D6 = 24
LCD_D7 = 25

# Define características del LCD
LCD_WIDTH = 20 # Caracteres por línea
LCD_CHR = True
LCD_CMD = False

LINE_1 = 0x80   # LCD RAM Dirección de la primer línea
LINE_2 = 0xC0   # LCD RAM Dirección de la segunda línea
LINE_3 = 0x94 # LCD RAM address for the 3rd line
LINE_4 = 0xD4 # LCD RAM address for the 4th line

# Tiempos constantes
E_PULSE = 0.0003   #5
E_DELAY = 0.0003   #5

#GPIO.setmode(GPIO.BOARD) # Se usa el mapa de pines BOARD
GPIO.setmode(GPIO.BCM)  # Se usa el mapa de pines BCM
GPIO.setup(LCD_E, GPIO.OUT) # E
GPIO.setup(LCD_RS, GPIO.OUT) # RS
GPIO.setup(LCD_D4, GPIO.OUT) # DB4
GPIO.setup(LCD_D5, GPIO.OUT) # DB5
GPIO.setup(LCD_D6, GPIO.OUT) # DB6
GPIO.setup(LCD_D7, GPIO.OUT) # DB7

#def main():
   #lcd_init()
   #lcd_string(" Test Libreria ",LINE_1)
   #lcd_string(" LCD 16x2 ",LINE_2)
   #time.sleep(5)

def lcd_init():
   # Initialise display
   lcd_byte(0x33,LCD_CMD) # 110011 Inicia config
   lcd_byte(0x32,LCD_CMD) # 110010 Inicia config
   lcd_byte(0x06,LCD_CMD) # 000110 Cursor mueve a la derecha
   lcd_byte(0x0C,LCD_CMD) # 001100 Display On,Cursor Off, Blink Off
   lcd_byte(0x28,LCD_CMD) # 101000 Bus 4bit, número de líneas y tipo de fuente
   lcd_byte(0x01,LCD_CMD) # 000001 Clear display
   time.sleep(E_DELAY)

def lcd_byte(bits, mode):
   # Envía byte a los pines de datos
   # bits = dato
   # modo = True para un dato caracter
   #        False para un comando

   GPIO.output(LCD_RS, mode) # RS

   # High bits
   GPIO.output(LCD_D4, False)
   GPIO.output(LCD_D5, False)
   GPIO.output(LCD_D6, False)
   GPIO.output(LCD_D7, False)
   if bits&0x10==0x10:
      GPIO.output(LCD_D4, True)
   if bits&0x20==0x20:
      GPIO.output(LCD_D5, True)
   if bits&0x40==0x40:
      GPIO.output(LCD_D6, True)
   if bits&0x80==0x80:
      GPIO.output(LCD_D7, True)

   # Toggle 'Habilita' pin
   lcd_toggle_enable()

   # Low bits
   GPIO.output(LCD_D4, False)
   GPIO.output(LCD_D5, False)
   GPIO.output(LCD_D6, False)
   GPIO.output(LCD_D7, False)
   if bits&0x01==0x01:
      GPIO.output(LCD_D4, True)
   if bits&0x02==0x02:
      GPIO.output(LCD_D5, True)
   if bits&0x04==0x04:
      GPIO.output(LCD_D6, True)
   if bits&0x08==0x08:
      GPIO.output(LCD_D7, True)

   # Toggle 'Enable' pin
   lcd_toggle_enable()

def lcd_toggle_enable():
   # Toggle enable
   time.sleep(E_DELAY)
   GPIO.output(LCD_E, True)
   time.sleep(E_PULSE)
   GPIO.output(LCD_E, False)
   time.sleep(E_DELAY)

def lcd_string(message,line):
# Send string to display

   message = message.ljust(LCD_WIDTH," ")

   lcd_byte(line, LCD_CMD)

   for i in range(LCD_WIDTH):
      lcd_byte(ord(message[i]),LCD_CHR)
