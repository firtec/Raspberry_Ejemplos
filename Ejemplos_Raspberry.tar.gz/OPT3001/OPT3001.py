# -*- coding: utf-8 -*-
"""
/*****************************************************************************
*  Descripción  : Ejemplo de uso para el sensor OPT3001
*                 Sensor I2C para medición de luz visible.
*                 Este ejemplo utiliza I2C1 de Raspberry PI
*  Target       : Raspberry PI 3
*  Python       : 3.9
*         www.firtec.com.ar
*****************************************************************************/
"""

import smbus
import time
import sys
import RPi.GPIO as GPIO

from tkinter import *
from tkinter.messagebox import showinfo

DEVICE_BUS = 1
DEVICE_ADDR = 0x44
bus = smbus.SMBus(1)

class MyGui(Frame):
    def __init__(self, parent=None):
        Frame.__init__(self, parent)
ventana = Tk()

ventana.title('Sensor OPT3001')
ventana.config(bg="NavajoWhite2") 
ventana.geometry("350x200")


ventana.resizable(0,0)

"""
/******************************************************************************
*  Configura el registro de control de sensor
*  Registro de configuración en dirección 0x01
*  Configura el conversor A/D       dato = 0xC6
*  Configura conversión continua    dato = 0x10
******************************************************************************/
"""
def Configurar_Sensor():
    bus.write_i2c_block_data(DEVICE_ADDR, 0x01,[0xC6,0x10])
    time.sleep(1)
    return 
"""
/******************************************************************************
*  Función para leer la cantidad de luz visible
*
******************************************************************************/
"""
def Leer_Lum():
      tmp_data = [0,0]
      tmp_data = bus.read_i2c_block_data(DEVICE_ADDR, 0, 2)
      DataSum = ((tmp_data[0] << 8) | tmp_data[1])        
      tmp_data[0] = tmp_data[0] >> 4;                      
      DataSum = DataSum << 4;                              
      DataSum = DataSum >> 4; 
      Ambient_Data = 0.01 * (2 << tmp_data[0]) * DataSum                           

      if Ambient_Data >= 1000.0:
          Ambient_Data = 1000.0

      Ambient_Data  /= 10
      label_datoLum.config(text = "% 2.1f%% " %Ambient_Data)
      ventana.after(1, Leer_Lum)

label_cartel = Label(ventana, text="Porcentual de Luz Visible", bg="NavajoWhite2",fg="blue", font=("Helvetica", 15))
label_cartel.place(x=60, y=27)

label_datoLum = Label(ventana, text="", bg="NavajoWhite2",fg="black", font=("Helvetica", 28))
label_datoLum.place(x=110, y=70)

label_firtec = Label(ventana, text="www.firtec.com.ar", bg="NavajoWhite2", fg="black", font=("bold", 10))
label_firtec.place(x=110, y=133)

Configurar_Sensor()

Leer_Lum()
ventana.mainloop( )
GPIO.cleanup()
print ("Terminado :)")
