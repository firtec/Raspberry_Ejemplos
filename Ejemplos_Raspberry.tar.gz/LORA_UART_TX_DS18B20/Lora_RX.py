import binascii
import time
from serial import Serial
import RPi.GPIO as GPIO # Modulo para gestionar los pines GPIO

GPIO.setwarnings(False) # Ignora las advertencias
GPIO.setmode(GPIO.BCM) 	# Los pines serán referidos como Broadcom

puerto = Serial("/dev/ttyS0", baudrate=9600, timeout=0.2)
if puerto.isOpen() == False:
    puerto.open()

puerto.flushInput()
puerto.flushOutput()
datos_viejos = 0    
while 1:   
    try: 
        datos_lora= puerto.readline().decode('utf-8').rstrip()
        
        if (datos_lora != ''):
            if (datos_viejos != datos_lora):
                datos_viejos = datos_lora
                print ('Datos de Arduino & Lora:')
                print (datos_lora)
                print ('========================')
       
    except (KeyboardInterrupt, SystemExit):
        puerto.close()
        GPIO.cleanup()
        raise
