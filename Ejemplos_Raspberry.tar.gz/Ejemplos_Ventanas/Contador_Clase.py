# ===============================================================
# - Ejemplo con un menu y el manejo de métodos (funciones)
# - (Este ejemplo utiliza una clase para la ventana principal)
# - Firtec Argentina
# - www.firtec.com.ar
# ===============================================================
# -*- coding: utf-8 -*-
#!/usr/bin/env python

from tkinter.messagebox import showinfo
from tkinter import *
import tkinter as tk

class Aplicacion:
        def __init__(self, root):
            self.valor = 0
            
            root.title("Prueba Contador")
        
            root.config(bg="beige") # Le da color al fondo
            root.geometry("400x200") # Cambia el tamaño de la ventana
            root.resizable(0,0) # Evita que se le pueda cambiar de tamaño a la ventana
            self.label=tk.Label(root, text=self.valor)
            self.label = tk.Label(root, text="0", bg="beige", fg="blue", font=("Helvetica", 40))
            self.label.place(x=140, y=10)
               
            self.boton_0 = tk.Button(root,text="Icrementar",command=self.incrementar)
            self.boton_0.place(x=20, y=50)   
            self.boton2 = tk.Button(root, text="Decrementar", command=self.decrementar)
            self.boton2.place(x=20, y=100)
            
        # Crear el menu principal
            menubarra = Menu(root)
        
            menubarra.add_command(label="Salir", command=ventana.destroy)
            menubarra.add_separator()
            menubarra.add_command(label="Info", command= self.info)

        # Mostrar el menu
            root.config(menu=menubarra)
        
           
        def info(self):
            showinfo(title='Acerca de..', message='Script en Python 3.9 \n www.firtec.com.ar')

        def decrementar(self):
            self.valor = self.valor - 1
            if (self.valor < 0):
                    self.valor = 0
            self.label.config(text=self.valor)

        def incrementar(self):
            self.valor=self.valor+1
            if (self.valor > 9):
                    self.valor = 9
            self.label.config(text=self.valor)


ventana = tk.Tk()
window = Aplicacion(ventana)
ventana.mainloop()

