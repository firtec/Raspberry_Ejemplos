#! /usr/bin/python
# -*- coding: utf-8 -*-
import RPi.GPIO as GPIO
import time
import LCDLIB16x2 as LCD
import spidev

#GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
spi = spidev.SpiDev()
spi.open(0, 0)
spi.max_speed_hz = 7629
LCD.lcd_init()
time.sleep(1)
LCD.lcd_string("  MCP3201 & PI",LCD.LINE_1)


def Conversor():
    M0 =0
    muestras =0
    while muestras <= 14:
        adc = spi.xfer2([0, 0])
        hi = (adc[0] & 0x1F);
        low = (adc[1] & 0xFe);
        dato = (hi << 8) | low;
        M0 += dato
        muestras += 1

    dato = M0 / 15
    Va = (dato) * 3.3 / 8192.0;
        #print "Voltios:% .3f" % Va
    LCD.lcd_string("Voltios:%.2f" % Va, LCD.LINE_2)

#**************************************************************************

while True:
    try:
        Conversor()
        #time.sleep(0.8)
    except (KeyboardInterrupt, SystemExit):
        spi.close()
        GPIO.cleanup()
        raise


